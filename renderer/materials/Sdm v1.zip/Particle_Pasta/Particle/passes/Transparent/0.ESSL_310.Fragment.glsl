#version 310 es
precision mediump float;
precision highp int;

uniform highp sampler2D s_ParticleTexture;

in highp vec4 v_color0;
in highp vec4 v_fog;
in highp vec2 v_texcoord0;
layout(location = 0) out highp vec4 bgfx_FragColor;

void main()
{
    highp vec4 _684 = v_color0;
    highp vec4 _620 = v_fog;
    highp vec4 _504 = texture(s_ParticleTexture, v_texcoord0) * vec4(v_color0.xyz, _684.w);
    highp vec3 _530 = mix(_504.xyz, v_fog.xyz, vec3(_620.w));
    highp vec4 _487 = vec4(_530.x, _530.y, _530.z, _504.w);
    highp vec4 _542 = vec4(_530, _487.w);
    highp vec4 _664 = v_fog;
    highp vec3 _568 = mix(_542.xyz, v_fog.xyz, vec3(_664.w));
    bgfx_FragColor = vec4(_568.x, _568.y, _568.z, _542.w);
}

