#version 300 es

uniform mat4 u_viewProj;
uniform mat4 u_model[4];
uniform vec4 FogAndDistanceControl;
uniform vec4 FogColor;

in vec4 a_color0;
in vec3 a_position;
in vec2 a_texcoord0;
out vec4 v_color0;
out vec4 v_fog;
out vec2 v_texcoord0;
out vec3 v_worldPos;

void main()
{
    vec4 _411 = u_model[0] * vec4(a_position, 1.0);
    vec4 _419 = u_viewProj * vec4(_411.xyz, 1.0);
    vec4 _476 = _419;
    v_color0 = a_color0;
    v_fog = vec4(FogColor.xyz, clamp(((_476.z / FogAndDistanceControl.z) - FogAndDistanceControl.x) / (FogAndDistanceControl.y - FogAndDistanceControl.x), 0.0, 1.0));
    v_texcoord0 = a_texcoord0;
    v_worldPos = _411.xyz;
    gl_Position = _419;
}

