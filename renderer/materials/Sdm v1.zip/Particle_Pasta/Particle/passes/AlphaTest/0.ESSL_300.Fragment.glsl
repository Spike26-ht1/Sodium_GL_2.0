#version 300 es
precision mediump float;
precision highp int;

uniform highp sampler2D s_ParticleTexture;

in highp vec4 v_color0;
in highp vec4 v_fog;
in highp vec2 v_texcoord0;
layout(location = 0) out highp vec4 bgfx_FragColor;

void main()
{
    highp vec4 _670 = v_color0;
    highp vec4 _483 = texture(s_ParticleTexture, v_texcoord0);
    if (_483.w < 0.5)
    {
        discard;
    }
    _483 *= vec4(v_color0.xyz, _670.w);
    _483.w = 1.0;
    highp vec4 _526 = vec4(_483.xyz, _483.w);
    highp vec4 _650 = v_fog;
    highp vec3 _552 = mix(_526.xyz, v_fog.xyz, vec3(_650.w));
    bgfx_FragColor = vec4(_552.x, _552.y, _552.z, _526.w);
}

