#version 310 es

uniform mat4 u_viewProj;
uniform vec4 FogAndDistanceControl;
uniform vec4 FogColor;

in vec4 a_color0;
in vec3 a_position;
in vec2 a_texcoord0;
in vec4 i_data1;
in vec4 i_data2;
in vec4 i_data3;
out vec4 v_color0;
out vec4 v_fog;
out vec2 v_texcoord0;
out vec3 v_worldPos;

void main()
{
    vec4 _591 = i_data1;
    vec4 _592 = i_data2;
    vec4 _593 = i_data3;
    mat4 _458;
    _458[0] = vec4(_591.x, _592.x, _593.x, 0.0);
    _458[1] = vec4(_591.y, _592.y, _593.y, 0.0);
    _458[2] = vec4(_591.z, _592.z, _593.z, 0.0);
    _458[3] = vec4(_591.w, _592.w, _593.w, 1.0);
    vec4 _520 = _458 * vec4(a_position, 1.0);
    highp vec3 pc_particle_world = _520.xyz;
    highp vec3 pc_particle_cull_delta = CullingCameraPosition.xyz - pc_particle_world;
    if (dot(pc_particle_cull_delta, pc_particle_cull_delta) > 1024.0)
    {
        gl_Position = vec4(2.0);
        return;
    }
    vec4 _511 = u_viewProj * vec4(_520.xyz, 1.0);
    vec4 _571 = _511;
    v_color0 = a_color0;
    v_fog = vec4(FogColor.xyz, clamp(((_571.z / FogAndDistanceControl.z) - FogAndDistanceControl.x) / (FogAndDistanceControl.y - FogAndDistanceControl.x), 0.0, 1.0));
    v_texcoord0 = a_texcoord0;
    v_worldPos = _520.xyz;
    gl_Position = _511;
}

