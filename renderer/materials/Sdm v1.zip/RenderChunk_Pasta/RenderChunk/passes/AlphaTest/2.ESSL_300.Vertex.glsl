#version 300 es

uniform mat4 u_proj;
uniform mat4 u_view;
uniform mat4 u_model[4];
uniform vec4 ViewPositionAndTime;
uniform vec4 FogAndDistanceControl;
uniform vec4 RenderChunkFogAlpha;
uniform vec4 FogColor;
uniform vec4 SubPixelOffset;

in vec4 a_color0;
in vec2 a_texcoord1;
in vec3 a_position;
in vec2 a_texcoord0;
out vec4 v_color0;
out vec4 v_fog;
out vec2 v_lightmapUV;
centroid out vec2 v_texcoord0;
out vec3 v_worldPos;

void main()
{
    vec4 _468 = u_model[0] * vec4(a_position, 1.0);
    vec3 _469 = _468.xyz;
    mat4 _542 = u_proj;
    _542[2].x += SubPixelOffset.x;
    _542[2].y -= SubPixelOffset.y;
    v_color0 = a_color0;
    v_fog = vec4(FogColor.xyz, clamp((((length(ViewPositionAndTime.xyz - _469) / FogAndDistanceControl.z) + RenderChunkFogAlpha.x) - FogAndDistanceControl.x) / (FogAndDistanceControl.y - FogAndDistanceControl.x), 0.0, 1.0));
    v_lightmapUV = a_texcoord1;
    v_texcoord0 = a_texcoord0;
    v_worldPos = _469;
    gl_Position = _542 * (u_view * vec4(_468.xyz, 1.0));
}

