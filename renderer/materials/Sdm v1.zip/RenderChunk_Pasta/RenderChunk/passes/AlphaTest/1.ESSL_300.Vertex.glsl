#version 300 es

uniform mat4 u_proj;
uniform mat4 u_view;
uniform vec4 ViewPositionAndTime;
uniform vec4 FogAndDistanceControl;
uniform vec4 RenderChunkFogAlpha;
uniform vec4 FogColor;
uniform vec4 SubPixelOffset;

in vec4 a_color0;
in vec2 a_texcoord1;
in vec3 a_position;
in vec2 a_texcoord0;
in vec4 i_data1;
in vec4 i_data2;
in vec4 i_data3;
out vec4 v_color0;
out vec4 v_fog;
out vec2 v_lightmapUV;
centroid out vec2 v_texcoord0;
out vec3 v_worldPos;

void main()
{
    vec4 _720 = i_data1;
    vec4 _721 = i_data2;
    vec4 _722 = i_data3;
    mat4 _514;
    _514[0] = vec4(_720.x, _721.x, _722.x, 0.0);
    _514[1] = vec4(_720.y, _721.y, _722.y, 0.0);
    _514[2] = vec4(_720.z, _721.z, _722.z, 0.0);
    _514[3] = vec4(_720.w, _721.w, _722.w, 1.0);
    vec4 _576 = _514 * vec4(a_position, 1.0);
    vec3 _560 = _576.xyz;
    mat4 _637 = u_proj;
    _637[2].x += SubPixelOffset.x;
    _637[2].y -= SubPixelOffset.y;
    v_color0 = a_color0;
    v_fog = vec4(FogColor.xyz, clamp((((length(ViewPositionAndTime.xyz - _560) / FogAndDistanceControl.z) + RenderChunkFogAlpha.x) - FogAndDistanceControl.x) / (FogAndDistanceControl.y - FogAndDistanceControl.x), 0.0, 1.0));
    v_lightmapUV = a_texcoord1;
    v_texcoord0 = a_texcoord0;
    v_worldPos = _560;
    gl_Position = _637 * (u_view * vec4(_576.xyz, 1.0));
}

