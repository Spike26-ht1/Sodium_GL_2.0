#version 310 es
precision mediump float;
precision highp int;

uniform highp vec4 FogColor;
uniform highp sampler2D s_LightMapTexture;
uniform highp sampler2D s_MatTexture;

in highp vec4 v_color0;
in highp vec4 v_fog;
in highp vec2 v_lightmapUV;
centroid in highp vec2 v_texcoord0;
layout(location = 0) out highp vec4 bgfx_FragColor;

void main()
{
    highp vec4 _503 = texture(s_MatTexture, v_texcoord0);
    if (_503.w < 0.5)
    {
        discard;
    }
    highp vec4 _516 = _503;
    highp vec3 _518 = _516.xyz * v_color0.xyz;
    _503 = vec4(_518.x, _518.y, _518.z, _516.w);
    highp vec4 _555 = vec4(texture(s_LightMapTexture, v_lightmapUV).xyz * _518.xyz, _503.w);
    highp vec4 _689 = v_fog;
    highp vec3 _575 = mix(_555.xyz, FogColor.xyz, vec3(_689.w));
    bgfx_FragColor = vec4(_575.x, _575.y, _575.z, _555.w);
}

