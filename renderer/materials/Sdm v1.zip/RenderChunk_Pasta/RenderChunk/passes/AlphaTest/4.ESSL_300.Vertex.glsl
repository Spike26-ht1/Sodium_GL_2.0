#version 300 es

uniform mat4 u_proj;
uniform mat4 u_view;
uniform mat4 u_model[4];
uniform vec4 ViewPositionAndTime;
uniform vec4 FogAndDistanceControl;
uniform vec4 RenderChunkFogAlpha;
uniform vec4 FogColor;
uniform vec4 SubPixelOffset;

in vec4 a_color0;
in vec2 a_texcoord1;
in vec3 a_position;
in vec2 a_texcoord0;
out vec4 v_color0;
out vec4 v_fog;
out vec2 v_lightmapUV;
centroid out vec2 v_texcoord0;
out vec3 v_worldPos;

void main()
{
    vec3 _532 = (u_model[0] * vec4(a_position, 1.0)).xyz;
    vec3 _603 = _532 + vec3(0.5);
    vec3 _610 = normalize(_603 - ViewPositionAndTime.xyz);
    vec3 _613 = normalize(cross(vec3(0.0, 1.0, 0.0), _610));
    vec3 _600 = a_color0.xyz;
    vec3 _633 = _603 - ((cross(_610, _613) * (_600.z - 0.5)) + (_613 * (_600.x - 0.5)));
    mat4 _660 = u_proj;
    _660[2].x += SubPixelOffset.x;
    _660[2].y -= SubPixelOffset.y;
    v_color0 = vec4(1.0);
    v_fog = vec4(FogColor.xyz, clamp((((length(ViewPositionAndTime.xyz - _633) / FogAndDistanceControl.z) + RenderChunkFogAlpha.x) - FogAndDistanceControl.x) / (FogAndDistanceControl.y - FogAndDistanceControl.x), 0.0, 1.0));
    v_lightmapUV = a_texcoord1;
    v_texcoord0 = a_texcoord0;
    v_worldPos = _532;
    gl_Position = _660 * (u_view * vec4(_633, 1.0));
}

