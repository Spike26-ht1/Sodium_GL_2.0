#version 310 es

uniform mat4 u_proj;
uniform mat4 u_view;
uniform vec4 ViewPositionAndTime;
uniform vec4 FogAndDistanceControl;
uniform vec4 RenderChunkFogAlpha;
uniform vec4 FogColor;
uniform vec4 SubPixelOffset;

in vec4 a_color0;
in vec2 a_texcoord1;
in vec3 a_position;
in vec2 a_texcoord0;
in vec4 i_data1;
in vec4 i_data2;
in vec4 i_data3;
out vec4 v_color0;
out vec4 v_fog;
out vec2 v_lightmapUV;
centroid out vec2 v_texcoord0;
out vec3 v_worldPos;

void main()
{
    vec4 _878 = i_data1;
    vec4 _879 = i_data2;
    vec4 _880 = i_data3;
    mat4 _577;
    _577[0] = vec4(_878.x, _879.x, _880.x, 0.0);
    _577[1] = vec4(_878.y, _879.y, _880.y, 0.0);
    _577[2] = vec4(_878.z, _879.z, _880.z, 0.0);
    _577[3] = vec4(_878.w, _879.w, _880.w, 1.0);
    vec3 _623 = (_577 * vec4(a_position, 1.0)).xyz;
    vec3 _698 = _623 + vec3(0.5);
    vec3 _705 = normalize(_698 - ViewPositionAndTime.xyz);
    vec3 _708 = normalize(cross(vec3(0.0, 1.0, 0.0), _705));
    vec3 _695 = a_color0.xyz;
    vec3 _728 = _698 - ((cross(_705, _708) * (_695.z - 0.5)) + (_708 * (_695.x - 0.5)));
    mat4 _755 = u_proj;
    _755[2].x += SubPixelOffset.x;
    _755[2].y -= SubPixelOffset.y;
    v_color0 = vec4(1.0);
    v_fog = vec4(FogColor.xyz, clamp((((length(ViewPositionAndTime.xyz - _728) / FogAndDistanceControl.z) + RenderChunkFogAlpha.x) - FogAndDistanceControl.x) / (FogAndDistanceControl.y - FogAndDistanceControl.x), 0.0, 1.0));
    v_lightmapUV = a_texcoord1;
    v_texcoord0 = a_texcoord0;
    v_worldPos = _623;
    gl_Position = _755 * (u_view * vec4(_728, 1.0));
}

