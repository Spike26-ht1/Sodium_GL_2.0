#version 300 es
precision mediump float;
precision highp int;

uniform highp vec4 FogColor;
uniform highp sampler2D s_LightMapTexture;
uniform highp sampler2D s_MatTexture;
uniform highp sampler2D s_SeasonsTexture;

in highp vec4 v_color0;
in highp vec4 v_fog;
in highp vec2 v_lightmapUV;
centroid in highp vec2 v_texcoord0;
layout(location = 0) out highp vec4 bgfx_FragColor;

void main()
{
    highp vec4 _801 = v_color0;
    highp vec4 _552 = texture(s_MatTexture, v_texcoord0);
    if (_552.w < 0.5)
    {
        discard;
    }
    highp vec3 _554 = v_color0.xyz;
    highp vec3 _608 = (_552.xyz * mix(vec3(1.0), texture(s_SeasonsTexture, v_color0.xy).xyz * 2.0, vec3(_554.z))).xyz * vec3(_801.w);
    highp vec4 _556 = vec4(_608.x, _608.y, _608.z, _552.w);
    _556.w = 1.0;
    _552 = _556;
    highp vec4 _643 = vec4(texture(s_LightMapTexture, v_lightmapUV).xyz * _556.xyz, _552.w);
    highp vec4 _779 = v_fog;
    highp vec3 _663 = mix(_643.xyz, FogColor.xyz, vec3(_779.w));
    bgfx_FragColor = vec4(_663.x, _663.y, _663.z, _643.w);
}

