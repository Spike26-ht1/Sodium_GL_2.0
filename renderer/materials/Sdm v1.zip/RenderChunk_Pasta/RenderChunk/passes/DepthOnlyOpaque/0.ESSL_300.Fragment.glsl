#version 300 es
precision mediump float;
precision highp int;

uniform highp vec4 FogColor;
uniform highp sampler2D s_LightMapTexture;

in highp vec4 v_fog;
in highp vec2 v_lightmapUV;
layout(location = 0) out highp vec4 bgfx_FragColor;

void main()
{
    highp vec4 _495 = vec4(texture(s_LightMapTexture, v_lightmapUV).xyz, 1.0);
    highp vec4 _590 = v_fog;
    highp vec3 _515 = mix(_495.xyz, FogColor.xyz, vec3(_590.w));
    bgfx_FragColor = vec4(_515.x, _515.y, _515.z, _495.w);
}

