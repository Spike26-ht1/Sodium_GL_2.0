#version 300 es
precision mediump float;
precision highp int;

uniform highp vec4 FogColor;
uniform highp sampler2D s_LightMapTexture;
uniform highp sampler2D s_MatTexture;

in highp vec4 v_color0;
in highp vec4 v_fog;
in highp vec2 v_lightmapUV;
centroid in highp vec2 v_texcoord0;
layout(location = 0) out highp vec4 bgfx_FragColor;

void main()
{
    highp vec4 _704 = v_color0;
    highp vec4 _501 = texture(s_MatTexture, v_texcoord0);
    _501.w *= _704.w;
    highp vec4 _514 = _501;
    highp vec3 _516 = _514.xyz * v_color0.xyz;
    _501 = vec4(_516.x, _516.y, _516.z, _514.w);
    highp vec4 _553 = vec4(texture(s_LightMapTexture, v_lightmapUV).xyz * _516.xyz, _501.w);
    highp vec4 _682 = v_fog;
    highp vec3 _573 = mix(_553.xyz, FogColor.xyz, vec3(_682.w));
    bgfx_FragColor = vec4(_573.x, _573.y, _573.z, _553.w);
}

