#version 300 es

uniform mat4 u_proj;
uniform mat4 u_view;
uniform mat4 u_model[4];
uniform vec4 FogAndDistanceControl;
uniform vec4 ViewPositionAndTime;
uniform vec4 RenderChunkFogAlpha;
uniform vec4 FogColor;
uniform vec4 SubPixelOffset;

in vec4 a_color0;
in vec2 a_texcoord1;
in vec3 a_position;
in vec2 a_texcoord0;
out vec4 v_color0;
out vec4 v_fog;
out vec2 v_lightmapUV;
centroid out vec2 v_texcoord0;
out vec3 v_worldPos;

void main()
{
    vec3 _567 = (u_model[0] * vec4(a_position, 1.0)).xyz;
    vec4 _973 = a_color0;
    vec3 _665 = _567 + vec3(0.5);
    vec3 _672 = normalize(_665 - ViewPositionAndTime.xyz);
    vec3 _675 = normalize(cross(vec3(0.0, 1.0, 0.0), _672));
    vec3 _662 = a_color0.xyz;
    vec3 _695 = _665 - ((cross(_672, _675) * (_662.z - 0.5)) + (_675 * (_662.x - 0.5)));
    float _635 = length(ViewPositionAndTime.xyz - _695);
    mat4 _722 = u_proj;
    _722[2].x += SubPixelOffset.x;
    _722[2].y -= SubPixelOffset.y;
    vec4 _849 = vec4(1.0);
    if (_973.w < 0.949999988079071044921875)
    {
        _849.w = mix(_973.w, 1.0, clamp(_635 / FogAndDistanceControl.w, 0.0, 1.0));
    }
    v_color0 = _849;
    v_fog = vec4(FogColor.xyz, clamp((((_635 / FogAndDistanceControl.z) + RenderChunkFogAlpha.x) - FogAndDistanceControl.x) / (FogAndDistanceControl.y - FogAndDistanceControl.x), 0.0, 1.0));
    v_lightmapUV = a_texcoord1;
    v_texcoord0 = a_texcoord0;
    v_worldPos = _567;
    gl_Position = _722 * (u_view * vec4(_695, 1.0));
}

