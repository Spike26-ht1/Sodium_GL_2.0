#version 310 es

uniform mat4 u_proj;
uniform mat4 u_view;
uniform vec4 FogAndDistanceControl;
uniform vec4 ViewPositionAndTime;
uniform vec4 RenderChunkFogAlpha;
uniform vec4 FogColor;
uniform vec4 SubPixelOffset;

in vec4 a_color0;
in vec2 a_texcoord1;
in vec3 a_position;
in vec2 a_texcoord0;
in vec4 i_data1;
in vec4 i_data2;
in vec4 i_data3;
out vec4 v_color0;
out vec4 v_fog;
out vec2 v_lightmapUV;
centroid out vec2 v_texcoord0;
out vec3 v_worldPos;

void main()
{
    vec4 _963 = i_data1;
    vec4 _964 = i_data2;
    vec4 _965 = i_data3;
    mat4 _611;
    _611[0] = vec4(_963.x, _964.x, _965.x, 0.0);
    _611[1] = vec4(_963.y, _964.y, _965.y, 0.0);
    _611[2] = vec4(_963.z, _964.z, _965.z, 0.0);
    _611[3] = vec4(_963.w, _964.w, _965.w, 1.0);
    vec3 _657 = (_611 * vec4(a_position, 1.0)).xyz;
    vec4 _1100 = a_color0;
    vec3 _759 = _657 + vec3(0.5);
    vec3 _766 = normalize(_759 - ViewPositionAndTime.xyz);
    vec3 _769 = normalize(cross(vec3(0.0, 1.0, 0.0), _766));
    vec3 _756 = a_color0.xyz;
    vec3 _789 = _759 - ((cross(_766, _769) * (_756.z - 0.5)) + (_769 * (_756.x - 0.5)));
    float _729 = length(ViewPositionAndTime.xyz - _789);
    mat4 _816 = u_proj;
    _816[2].x += SubPixelOffset.x;
    _816[2].y -= SubPixelOffset.y;
    vec4 _943 = vec4(1.0);
    if (_1100.w < 0.949999988079071044921875)
    {
        _943.w = mix(_1100.w, 1.0, clamp(_729 / FogAndDistanceControl.w, 0.0, 1.0));
    }
    v_color0 = _943;
    v_fog = vec4(FogColor.xyz, clamp((((_729 / FogAndDistanceControl.z) + RenderChunkFogAlpha.x) - FogAndDistanceControl.x) / (FogAndDistanceControl.y - FogAndDistanceControl.x), 0.0, 1.0));
    v_lightmapUV = a_texcoord1;
    v_texcoord0 = a_texcoord0;
    v_worldPos = _657;
    gl_Position = _816 * (u_view * vec4(_789, 1.0));
}

