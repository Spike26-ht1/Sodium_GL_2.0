#version 300 es

uniform mat4 u_proj;
uniform mat4 u_view;
uniform vec4 FogAndDistanceControl;
uniform vec4 ViewPositionAndTime;
uniform vec4 RenderChunkFogAlpha;
uniform vec4 FogColor;
uniform vec4 SubPixelOffset;

in vec4 a_color0;
in vec2 a_texcoord1;
in vec3 a_position;
in vec2 a_texcoord0;
in vec4 i_data1;
in vec4 i_data2;
in vec4 i_data3;
out vec4 v_color0;
out vec4 v_fog;
out vec2 v_lightmapUV;
centroid out vec2 v_texcoord0;
out vec3 v_worldPos;

void main()
{
    vec4 _805 = i_data1;
    vec4 _806 = i_data2;
    vec4 _807 = i_data3;
    mat4 _548;
    _548[0] = vec4(_805.x, _806.x, _807.x, 0.0);
    _548[1] = vec4(_805.y, _806.y, _807.y, 0.0);
    _548[2] = vec4(_805.z, _806.z, _807.z, 0.0);
    _548[3] = vec4(_805.w, _806.w, _807.w, 1.0);
    vec4 _610 = _548 * vec4(a_position, 1.0);
    vec3 _594 = _610.xyz;
    vec4 _920 = a_color0;
    float _658 = length(ViewPositionAndTime.xyz - _594);
    mat4 _698 = u_proj;
    _698[2].x += SubPixelOffset.x;
    _698[2].y -= SubPixelOffset.y;
    vec4 _785 = a_color0;
    if (_920.w < 0.949999988079071044921875)
    {
        _785.w = mix(_920.w, 1.0, clamp(_658 / FogAndDistanceControl.w, 0.0, 1.0));
    }
    v_color0 = _785;
    v_fog = vec4(FogColor.xyz, clamp((((_658 / FogAndDistanceControl.z) + RenderChunkFogAlpha.x) - FogAndDistanceControl.x) / (FogAndDistanceControl.y - FogAndDistanceControl.x), 0.0, 1.0));
    v_lightmapUV = a_texcoord1;
    v_texcoord0 = a_texcoord0;
    v_worldPos = _594;
    gl_Position = _698 * (u_view * vec4(_610.xyz, 1.0));
}

