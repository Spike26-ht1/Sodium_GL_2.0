#version 300 es

uniform mat4 u_proj;
uniform mat4 u_view;
uniform mat4 u_model[4];
uniform vec4 FogAndDistanceControl;
uniform vec4 ViewPositionAndTime;
uniform vec4 RenderChunkFogAlpha;
uniform vec4 FogColor;
uniform vec4 SubPixelOffset;

in vec4 a_color0;
in vec2 a_texcoord1;
in vec3 a_position;
in vec2 a_texcoord0;
out vec4 v_color0;
out vec4 v_fog;
out vec2 v_lightmapUV;
centroid out vec2 v_texcoord0;
out vec3 v_worldPos;

void main()
{
    vec4 _503 = u_model[0] * vec4(a_position, 1.0);
    vec3 _504 = _503.xyz;
    vec4 _802 = a_color0;
    float _564 = length(ViewPositionAndTime.xyz - _504);
    mat4 _604 = u_proj;
    _604[2].x += SubPixelOffset.x;
    _604[2].y -= SubPixelOffset.y;
    vec4 _691 = a_color0;
    if (_802.w < 0.949999988079071044921875)
    {
        _691.w = mix(_802.w, 1.0, clamp(_564 / FogAndDistanceControl.w, 0.0, 1.0));
    }
    v_color0 = _691;
    v_fog = vec4(FogColor.xyz, clamp((((_564 / FogAndDistanceControl.z) + RenderChunkFogAlpha.x) - FogAndDistanceControl.x) / (FogAndDistanceControl.y - FogAndDistanceControl.x), 0.0, 1.0));
    v_lightmapUV = a_texcoord1;
    v_texcoord0 = a_texcoord0;
    v_worldPos = _504;
    gl_Position = _604 * (u_view * vec4(_503.xyz, 1.0));
}

