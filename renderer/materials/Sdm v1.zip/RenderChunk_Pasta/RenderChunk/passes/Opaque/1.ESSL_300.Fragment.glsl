#version 300 es
precision mediump float;
precision highp int;

uniform highp vec4 FogColor;
uniform highp sampler2D s_LightMapTexture;
uniform highp sampler2D s_MatTexture;
uniform highp sampler2D s_SeasonsTexture;

in highp vec4 v_color0;
in highp vec4 v_fog;
in highp vec2 v_lightmapUV;
centroid in highp vec2 v_texcoord0;
layout(location = 0) out highp vec4 bgfx_FragColor;

void main()
{
    highp vec4 _780 = v_color0;
    highp vec4 _570 = texture(s_MatTexture, v_texcoord0);
    highp vec3 _546 = v_color0.xyz;
    highp vec3 _594 = (_570.xyz * mix(vec3(1.0), texture(s_SeasonsTexture, v_color0.xy).xyz * 2.0, vec3(_546.z))).xyz * vec3(_780.w);
    highp vec4 _548 = vec4(_594.x, _594.y, _594.z, _570.w);
    _548.w = 1.0;
    highp vec4 _544 = _548;
    highp vec4 _629 = vec4(texture(s_LightMapTexture, v_lightmapUV).xyz * _548.xyz, _544.w);
    highp vec4 _758 = v_fog;
    highp vec3 _649 = mix(_629.xyz, FogColor.xyz, vec3(_758.w));
    bgfx_FragColor = vec4(_649.x, _649.y, _649.z, _629.w);
}

