#version 310 es
precision mediump float;
precision highp int;

uniform highp vec4 FogColor;
uniform highp sampler2D s_LightMapTexture;
uniform highp sampler2D s_MatTexture;

in highp vec4 v_color0;
in highp vec4 v_fog;
in highp vec2 v_lightmapUV;
centroid in highp vec2 v_texcoord0;
layout(location = 0) out highp vec4 bgfx_FragColor;

void main()
{
    highp vec4 _698 = v_color0;
    highp vec4 _525 = texture(s_MatTexture, v_texcoord0);
    highp vec3 _507 = _525.xyz * v_color0.xyz;
    highp vec4 _498 = vec4(_507.x, _507.y, _507.z, _525.w);
    _498.w = _698.w;
    highp vec4 _547 = vec4(texture(s_LightMapTexture, v_lightmapUV).xyz * _498.xyz, _498.w);
    highp vec4 _676 = v_fog;
    highp vec3 _567 = mix(_547.xyz, FogColor.xyz, vec3(_676.w));
    bgfx_FragColor = vec4(_567.x, _567.y, _567.z, _547.w);
}

