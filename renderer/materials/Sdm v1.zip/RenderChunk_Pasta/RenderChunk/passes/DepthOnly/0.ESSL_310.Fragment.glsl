#version 310 es
precision mediump float;
precision highp int;

uniform highp vec4 FogColor;
uniform highp sampler2D s_LightMapTexture;
uniform highp sampler2D s_MatTexture;

in highp vec4 v_fog;
in highp vec2 v_lightmapUV;
centroid in highp vec2 v_texcoord0;
layout(location = 0) out highp vec4 bgfx_FragColor;

void main()
{
    highp vec4 _487 = texture(s_MatTexture, v_texcoord0);
    if (_487.w < 0.5)
    {
        discard;
    }
    highp vec4 _523 = vec4(texture(s_LightMapTexture, v_lightmapUV).xyz, 1.0);
    highp vec4 _627 = v_fog;
    highp vec3 _543 = mix(_523.xyz, FogColor.xyz, vec3(_627.w));
    bgfx_FragColor = vec4(_543.x, _543.y, _543.z, _523.w);
}

